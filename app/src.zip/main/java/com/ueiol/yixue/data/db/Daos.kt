package com.ueiol.yixue.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SubjectDao {
    @Query("SELECT * FROM subjects ORDER BY `order` ASC, id ASC")
    fun observeAll(): Flow<List<SubjectEntity>>

    @Query("SELECT * FROM subjects WHERE id = :id")
    suspend fun getById(id: Long): SubjectEntity?

    @Query("SELECT * FROM subjects WHERE name = :name LIMIT 1")
    suspend fun getByName(name: String): SubjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(subject: SubjectEntity): Long

    @Update
    suspend fun update(subject: SubjectEntity)

    @Delete
    suspend fun delete(subject: SubjectEntity)

    @Query("SELECT COUNT(*) FROM subjects")
    suspend fun count(): Int
}

@Dao
interface SessionDao {
    // 置顶优先，其余按更新时间倒序
    @Query("SELECT * FROM sessions ORDER BY pinned DESC, updatedAt DESC")
    fun observeAll(): Flow<List<SessionEntity>>

    /** 只列有消息的会话：空会话不保存、不展示。 */
    @Query(
        """
        SELECT * FROM sessions s
        WHERE EXISTS (SELECT 1 FROM messages m WHERE m.sessionId = s.id)
        ORDER BY s.pinned DESC, s.updatedAt DESC
        """
    )
    fun observeAllNonEmpty(): Flow<List<SessionEntity>>

    /** 清理历史遗留的空会话。 */
    @Query("DELETE FROM sessions WHERE NOT EXISTS (SELECT 1 FROM messages m WHERE m.sessionId = sessions.id)")
    suspend fun deleteEmpty(): Int

    @Query("SELECT * FROM sessions WHERE id = :id")
    suspend fun getById(id: Long): SessionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(session: SessionEntity): Long

    @Update
    suspend fun update(session: SessionEntity)

    @Query("UPDATE sessions SET title = :title WHERE id = :id")
    suspend fun rename(id: Long, title: String)

    @Query("UPDATE sessions SET pinned = :pinned WHERE id = :id")
    suspend fun setPinned(id: Long, pinned: Boolean)

    @Delete
    suspend fun delete(session: SessionEntity)
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE sessionId = :sessionId ORDER BY createdAt ASC, id ASC")
    fun observeBySession(sessionId: Long): Flow<List<MessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(message: MessageEntity): Long

    @Update
    suspend fun update(message: MessageEntity)

    @Delete
    suspend fun delete(message: MessageEntity)

    @Query("DELETE FROM messages WHERE sessionId = :sessionId")
    suspend fun deleteBySession(sessionId: Long)
}

@Dao
interface QuizDao {
    @Query("SELECT * FROM quizzes WHERE sessionId = :sessionId ORDER BY createdAt DESC")
    fun observeBySession(sessionId: Long): Flow<List<QuizEntity>>

    @Query("SELECT * FROM quizzes WHERE id = :id")
    fun observeById(id: Long): Flow<QuizEntity?>

    @Query("SELECT * FROM quizzes WHERE id = :id")
    suspend fun getById(id: Long): QuizEntity?

    /** 测验记录：每卷的题量、已答数、答对数。 */
    @Query(
        """
        SELECT q.id AS id, q.title AS title, q.status AS status, q.createdAt AS createdAt,
            (SELECT COUNT(*) FROM questions qs WHERE qs.quizId = q.id) AS total,
            (SELECT COUNT(*) FROM questions qs
                JOIN answer_records r ON r.questionId = qs.id
                WHERE qs.quizId = q.id AND r.valueJson IS NOT NULL AND r.valueJson <> '') AS answered,
            (SELECT COUNT(*) FROM questions qs
                JOIN answer_records r ON r.questionId = qs.id
                WHERE qs.quizId = q.id AND r.state IN ('LOCAL_OK', 'AI_REVERSED')) AS correct
        FROM quizzes q
        WHERE q.status <> 'GENERATING'
        ORDER BY q.createdAt DESC
        """
    )
    fun observeSummaries(): Flow<List<QuizSummary>>

    @Query("UPDATE quizzes SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: Long, status: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(quiz: QuizEntity): Long

    @Delete
    suspend fun delete(quiz: QuizEntity)
}

@Dao
interface QuestionDao {
    @Query("SELECT * FROM questions WHERE quizId = :quizId ORDER BY `order` ASC")
    fun observeByQuiz(quizId: Long): Flow<List<QuestionEntity>>

    @Query("SELECT * FROM questions WHERE id = :id")
    suspend fun getById(id: Long): QuestionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(questions: List<QuestionEntity>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(question: QuestionEntity): Long

    @Update
    suspend fun update(question: QuestionEntity)

    @Delete
    suspend fun delete(question: QuestionEntity)

    @Query("DELETE FROM questions WHERE quizId = :quizId")
    suspend fun deleteByQuiz(quizId: Long)
}

@Dao
interface AnswerRecordDao {
    @Query("SELECT * FROM answer_records WHERE questionId = :questionId")
    suspend fun getByQuestionId(questionId: Long): AnswerRecordEntity?

    @Query("SELECT * FROM answer_records WHERE questionId IN (:questionIds)")
    suspend fun getByQuestionIds(questionIds: List<Long>): List<AnswerRecordEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(record: AnswerRecordEntity): Long

    @Update
    suspend fun update(record: AnswerRecordEntity)

    @Query("DELETE FROM answer_records WHERE questionId IN (:questionIds)")
    suspend fun deleteByQuestionIds(questionIds: List<Long>)
}

@Dao
interface WrongQuestionDao {
    @Query("SELECT * FROM wrong_questions WHERE mastered = 0 ORDER BY wrongAt DESC")
    fun observeActive(): Flow<List<WrongQuestionEntity>>

    @Query("SELECT * FROM wrong_questions WHERE subjectId = :subjectId AND mastered = 0 ORDER BY wrongAt DESC")
    fun observeActiveBySubject(subjectId: Long): Flow<List<WrongQuestionEntity>>

    @Query("SELECT * FROM wrong_questions WHERE id = :id")
    suspend fun getById(id: Long): WrongQuestionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(wrongQuestion: WrongQuestionEntity): Long

    @Query("UPDATE wrong_questions SET mastered = :mastered WHERE id = :id")
    suspend fun setMastered(id: Long, mastered: Boolean)

    @Query("UPDATE wrong_questions SET explanationReport = :report WHERE id = :id")
    suspend fun updateExplanationReport(id: Long, report: String)

    @Delete
    suspend fun delete(wrongQuestion: WrongQuestionEntity)
}

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes WHERE subjectId = :subjectId ORDER BY updatedAt DESC")
    fun observeBySubject(subjectId: Long): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes WHERE id = :id")
    suspend fun getById(id: Long): NoteEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(note: NoteEntity): Long

    @Update
    suspend fun update(note: NoteEntity)

    @Delete
    suspend fun delete(note: NoteEntity)
}
