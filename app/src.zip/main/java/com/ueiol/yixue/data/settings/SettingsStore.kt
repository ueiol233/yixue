package com.ueiol.yixue.data.settings

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class AiSettings(
    val baseUrl: String = "https://api.openai.com/v1",
    val apiKey: String = "",
    val model: String = "gpt-4o-mini",
    val temperature: Double = 0.7,
    val maxTokens: Int = 4096
)

/**
 * AI 服务配置存储：密钥用 EncryptedSharedPreferences，其余项用普通 prefs。
 * 加密存储初始化失败时降级为普通存储，不阻塞应用。
 */
class SettingsStore(context: Context) {

    private val plainPrefs: SharedPreferences =
        context.getSharedPreferences("yixue_settings", Context.MODE_PRIVATE)

    private val securePrefs: SharedPreferences? = try {
        val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
        EncryptedSharedPreferences.create(
            "yixue_secure_settings",
            masterKeyAlias,
            context,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (t: Throwable) {
        null
    }

    private val _settings = MutableStateFlow(load())
    val settings: StateFlow<AiSettings> = _settings

    val current: AiSettings get() = _settings.value

    private fun load(): AiSettings {
        val secure = securePrefs ?: plainPrefs
        val defaults = AiSettings()
        return AiSettings(
            baseUrl = plainPrefs.getString(KEY_BASE_URL, null) ?: defaults.baseUrl,
            apiKey = secure.getString(KEY_API_KEY, null) ?: "",
            model = plainPrefs.getString(KEY_MODEL, null)
                ?: plainPrefs.getString(KEY_TEXT_MODEL, null)
                ?: defaults.model,
            temperature = plainPrefs.getFloat(KEY_TEMPERATURE, 0.7f).toDouble(),
            maxTokens = plainPrefs.getInt(KEY_MAX_TOKENS, 4096)
        )
    }

    fun update(settings: AiSettings) {
        val secure = securePrefs ?: plainPrefs
        plainPrefs.edit()
            .putString(KEY_BASE_URL, settings.baseUrl)
            .putString(KEY_MODEL, settings.model)
            .putFloat(KEY_TEMPERATURE, settings.temperature.toFloat())
            .putInt(KEY_MAX_TOKENS, settings.maxTokens)
            .apply()
        secure.edit().putString(KEY_API_KEY, settings.apiKey).apply()
        _settings.value = settings
    }

    fun isConfigured(): Boolean = current.apiKey.isNotBlank() && current.baseUrl.isNotBlank()

    private companion object {
        const val KEY_BASE_URL = "base_url"
        const val KEY_API_KEY = "api_key"
        const val KEY_MODEL = "model"
        // 兼容旧版本字段
        const val KEY_TEXT_MODEL = "text_model"
        const val KEY_TEMPERATURE = "temperature"
        const val KEY_MAX_TOKENS = "max_tokens"
    }
}
