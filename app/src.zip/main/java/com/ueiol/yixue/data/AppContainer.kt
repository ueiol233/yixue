package com.ueiol.yixue.data

import android.content.Context
import com.ueiol.yixue.data.ai.OpenAiClient
import com.ueiol.yixue.data.db.YixueDatabase
import com.ueiol.yixue.data.repo.ChatRepository
import com.ueiol.yixue.data.repo.QuizRepository
import com.ueiol.yixue.data.settings.SettingsStore
import com.ueiol.yixue.domain.agent.QuizAgent

/**
 * 手写依赖注入容器（规划书：不引入 Hilt/Koin，保持精简）。
 * 进程级单例，由 [com.ueiol.yixue.YixueApp] 持有。
 */
class AppContainer(context: Context) {
    private val database: YixueDatabase = YixueDatabase.build(context.applicationContext)

    val settings = SettingsStore(context.applicationContext)
    val aiClient = OpenAiClient(settings)

    val subjectDao get() = database.subjectDao()
    val sessionDao get() = database.sessionDao()
    val messageDao get() = database.messageDao()
    val quizDao get() = database.quizDao()
    val questionDao get() = database.questionDao()
    val answerRecordDao get() = database.answerRecordDao()
    val wrongQuestionDao get() = database.wrongQuestionDao()
    val noteDao get() = database.noteDao()

    val chatRepository: ChatRepository by lazy {
        ChatRepository(sessionDao, messageDao)
    }

    val quizRepository: QuizRepository by lazy {
        QuizRepository(quizDao, questionDao, answerRecordDao)
    }

    val quizAgent: QuizAgent by lazy { QuizAgent(aiClient) }
    val reviewAgent: com.ueiol.yixue.domain.agent.ReviewAgent by lazy {
        com.ueiol.yixue.domain.agent.ReviewAgent(aiClient)
    }
}
