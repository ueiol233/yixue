package com.ueiol.yixue.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        SubjectEntity::class,
        SessionEntity::class,
        MessageEntity::class,
        QuizEntity::class,
        QuestionEntity::class,
        AnswerRecordEntity::class,
        WrongQuestionEntity::class,
        NoteEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class YixueDatabase : RoomDatabase() {
    abstract fun subjectDao(): SubjectDao
    abstract fun sessionDao(): SessionDao
    abstract fun messageDao(): MessageDao
    abstract fun quizDao(): QuizDao
    abstract fun questionDao(): QuestionDao
    abstract fun answerRecordDao(): AnswerRecordDao
    abstract fun wrongQuestionDao(): WrongQuestionDao
    abstract fun noteDao(): NoteDao

    companion object {
        fun build(context: Context): YixueDatabase =
            Room.databaseBuilder(context, YixueDatabase::class.java, "yixue.db")
                .fallbackToDestructiveMigration()
                .build()
    }
}
