package com.ueiol.yixue.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = FdPrimaryBlueLight,
    onPrimary = FdOnBrandLight,
    primaryContainer = FdPrimaryBlueContainerLight,
    onPrimaryContainer = FdOnPrimaryBlueContainerLight,
    secondary = FdPrimaryCyanLight,
    onSecondary = FdOnBrandLight,
    secondaryContainer = FdPrimaryCyanContainerLight,
    onSecondaryContainer = FdOnPrimaryCyanContainerLight,
    tertiary = FdPrimaryPurpleLight,
    onTertiary = FdOnBrandLight,
    tertiaryContainer = FdPrimaryPurpleContainerLight,
    onTertiaryContainer = FdOnPrimaryPurpleContainerLight,
    error = FdErrorLight,
    onError = FdOnErrorLight,
    errorContainer = FdErrorContainerLight,
    onErrorContainer = FdOnErrorContainerLight,
    background = FdSurfaceLight,
    onBackground = FdOnSurfaceLight,
    surface = FdSurfaceLight,
    onSurface = FdOnSurfaceLight,
    surfaceVariant = FdSurfaceContainerLight,
    onSurfaceVariant = FdOnSurfaceVariantLight,
    surfaceDim = FdSurfaceDimLight,
    surfaceBright = FdSurfaceBrightLight,
    surfaceContainerLowest = FdSurfaceLowestLight,
    surfaceContainerLow = FdSurfaceLowLight,
    surfaceContainer = FdSurfaceContainerLight,
    surfaceContainerHigh = FdSurfaceHighLight,
    surfaceContainerHighest = FdSurfaceHighestLight,
    outline = FdOutlineLight,
    outlineVariant = FdOutlineVariantLight,
    inverseSurface = FdInverseSurfaceLight,
    inverseOnSurface = FdInverseOnSurfaceLight,
    scrim = FdScrimLight
)

private val DarkColorScheme = darkColorScheme(
    primary = FdPrimaryBlueDark,
    onPrimary = FdOnBrandDark,
    primaryContainer = FdPrimaryBlueContainerDark,
    onPrimaryContainer = FdOnPrimaryBlueContainerDark,
    secondary = FdPrimaryCyanDark,
    onSecondary = FdOnBrandDark,
    secondaryContainer = FdPrimaryCyanContainerDark,
    onSecondaryContainer = FdOnPrimaryCyanContainerDark,
    tertiary = FdPrimaryPurpleDark,
    onTertiary = FdOnBrandDark,
    tertiaryContainer = FdPrimaryPurpleContainerDark,
    onTertiaryContainer = FdOnPrimaryPurpleContainerDark,
    error = FdErrorDark,
    onError = FdOnErrorDark,
    errorContainer = FdErrorContainerDark,
    onErrorContainer = FdOnErrorContainerDark,
    background = FdSurfaceDark,
    onBackground = FdOnSurfaceDark,
    surface = FdSurfaceDark,
    onSurface = FdOnSurfaceDark,
    surfaceVariant = FdSurfaceContainerDark,
    onSurfaceVariant = FdOnSurfaceVariantDark,
    surfaceDim = FdSurfaceDimDark,
    surfaceBright = FdSurfaceBrightDark,
    surfaceContainerLowest = FdSurfaceLowestDark,
    surfaceContainerLow = FdSurfaceLowDark,
    surfaceContainer = FdSurfaceContainerDark,
    surfaceContainerHigh = FdSurfaceHighDark,
    surfaceContainerHighest = FdSurfaceHighestDark,
    outline = FdOutlineDark,
    outlineVariant = FdOutlineVariantDark,
    inverseSurface = FdInverseSurfaceDark,
    inverseOnSurface = FdInverseOnSurfaceDark,
    scrim = FdScrimDark
)

/*
 * M3 色板之外的业务扩展色：对错反馈、科目色、状态色。
 */
@Immutable
data class FlymeExtendedColors(
    val success: Color,
    val onSuccess: Color,
    val successContainer: Color,
    val onSuccessContainer: Color,
    val warning: Color,
    val warningContainer: Color,
    val onWarningContainer: Color,
    val pressed: Color,
    val disabled: Color,
    // 科目色（浅/夜各一套，用于错题本、笔记、科目标签）
    val subjectBlue: Color,
    val subjectGreen: Color,
    val subjectOrange: Color,
    val subjectPurple: Color,
    val subjectYellow: Color,
    val subjectCyan: Color,
    val subjectRed: Color
)

private val LightExtendedColors = FlymeExtendedColors(
    success = FdPrimaryGreenLight,
    onSuccess = FdOnBrandLight,
    successContainer = FdPrimaryGreenContainerLight,
    onSuccessContainer = FdOnPrimaryGreenContainerLight,
    warning = FdPrimaryYellowLight,
    warningContainer = FdPrimaryYellowContainerLight,
    onWarningContainer = FdOnPrimaryYellowContainerLight,
    pressed = FdStatePressedLight,
    disabled = FdStateDisabledLight,
    subjectBlue = FdPrimaryBlueLight,
    subjectGreen = FdPrimaryGreenLight,
    subjectOrange = FdPrimaryOrangeLight,
    subjectPurple = FdPrimaryPurpleLight,
    subjectYellow = FdPrimaryYellowLight,
    subjectCyan = FdPrimaryCyanLight,
    subjectRed = FdPrimaryRedLight
)

private val DarkExtendedColors = FlymeExtendedColors(
    success = FdPrimaryGreenDark,
    onSuccess = FdOnBrandDark,
    successContainer = FdPrimaryGreenContainerDark,
    onSuccessContainer = FdOnPrimaryGreenContainerDark,
    warning = FdPrimaryYellowDark,
    warningContainer = FdPrimaryYellowContainerDark,
    onWarningContainer = FdOnPrimaryYellowContainerDark,
    pressed = FdStatePressedDark,
    disabled = FdStateDisabledDark,
    subjectBlue = FdPrimaryBlueDark,
    subjectGreen = FdPrimaryGreenDark,
    subjectOrange = FdPrimaryOrangeDark,
    subjectPurple = FdPrimaryPurpleDark,
    subjectYellow = FdPrimaryYellowDark,
    subjectCyan = FdPrimaryCyanDark,
    subjectRed = FdPrimaryRedDark
)

val LocalFlymeExtendedColors = staticCompositionLocalOf { LightExtendedColors }

/** 取扩展色的便捷入口：FlymeExt.current.success */
val FlymeExt: FlymeExtendedColors
    @Composable get() = LocalFlymeExtendedColors.current

/**
 * 易学主题（FlymeOS 10 范式）。
 * 深色模式默认跟随系统；[forceDark] 传值可强制指定（用于设置页手动切换）。
 * 不启用动态取色，保持 Flyme 品牌蓝视觉一致性。
 */
@Composable
fun YixueTheme(
    forceDark: Boolean? = null,
    content: @Composable () -> Unit
) {
    val darkTheme = forceDark ?: isSystemInDarkTheme()
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val extendedColors = if (darkTheme) DarkExtendedColors else LightExtendedColors

    CompositionLocalProvider(LocalFlymeExtendedColors provides extendedColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            shapes = FlymeShapes,
            content = content
        )
    }
}
