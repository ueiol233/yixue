package com.ueiol.yixue.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.ueiol.yixue.YixueApp
import com.ueiol.yixue.ui.common.FlymeLargeTitle
import kotlinx.coroutines.launch

data class PlatformPreset(val name: String, val baseUrl: String)

val PLATFORMS = listOf(
    PlatformPreset("DeepSeek", "https://api.deepseek.com/v1"),
    PlatformPreset("硅基流动", "https://api.siliconflow.cn/v1"),
    PlatformPreset("智谱GLM", "https://open.bigmodel.cn/api/paas/v4"),
    PlatformPreset("Kimi", "https://api.moonshot.cn/v1"),
    PlatformPreset("通义千问", "https://dashscope.aliyuncs.com/compatible-mode/v1"),
    PlatformPreset("OpenAI", "https://api.openai.com/v1")
)

@Composable
fun ApiSettingsPage(onBack: () -> Unit, modifier: Modifier = Modifier) {
    val app = LocalContext.current.applicationContext as YixueApp
    val store = app.container.settings
    val current = store.settings.value

    var baseUrl by remember { mutableStateOf(current.baseUrl) }
    var apiKey by remember { mutableStateOf(current.apiKey) }
    var model by remember { mutableStateOf(current.model) }
    var temperature by remember { mutableStateOf(current.temperature.toString()) }
    var maxTokens by remember { mutableStateOf(current.maxTokens.toString()) }
    var saved by remember { mutableStateOf(false) }
    var testing by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<String?>(null) }
    var testOk by remember { mutableStateOf(false) }
    var modelMsg by remember { mutableStateOf<String?>(null) }
    var fetchingModels by remember { mutableStateOf(false) }
    var modelList by remember { mutableStateOf<List<String>>(emptyList()) }
    var showModelPicker by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun persist() {
        store.update(
            store.current.copy(
                baseUrl = baseUrl.trim(), apiKey = apiKey.trim(), model = model.trim(),
                temperature = temperature.toDoubleOrNull() ?: 0.7,
                maxTokens = maxTokens.toIntOrNull() ?: 4096
            )
        )
    }
    Column(modifier = modifier.fillMaxSize().verticalScroll(rememberScrollState()).imePadding()) {
        FlymeLargeTitle(title = "AI 服务设置", actions = {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "返回", tint = MaterialTheme.colorScheme.onSurface)
            }
        })
        Column(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("平台预设", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PLATFORMS.forEach { p ->
                    FilterChip(
                        selected = baseUrl.trim().trimEnd('/') == p.baseUrl,
                        onClick = { baseUrl = p.baseUrl; saved = false },
                        label = { Text(p.name) }
                    )
                }
            }
            SettingsField("接口地址（填到 /v1 即可，自动补 /chat/completions）", baseUrl) { baseUrl = it; saved = false }
            SettingsField("API Key", apiKey, isPassword = true) { apiKey = it; saved = false }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        fetchingModels = true
                        modelMsg = null
                        persist()
                        scope.launch {
                            try {
                                val list = app.container.aiClient.listModels()
                                modelList = list
                                if (list.isEmpty()) modelMsg = "接口未返回可用模型" else showModelPicker = true
                            } catch (t: Throwable) {
                                modelMsg = "拉取失败：${t.message?.take(200)}"
                            } finally {
                                fetchingModels = false
                            }
                        }
                    },
                    enabled = !fetchingModels
                ) {
                    if (fetchingModels) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                    else Text("拉取模型列表")
                }
                modelMsg?.let { Text(it, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.error) }
            }
            SettingsField("模型（支持视觉/看图）", model) { model = it; saved = false }
            SettingsField("温度 0-2", temperature) { temperature = it; saved = false }
            SettingsField("最大 tokens", maxTokens) { maxTokens = it; saved = false }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { persist(); saved = true }) { Text("保存") }
                Spacer(Modifier.size(12.dp))
                OutlinedButton(onClick = {
                    testing = true; testResult = null
                    persist()
                    scope.launch {
                        val err = app.container.aiClient.testConnection()
                        testOk = err == null
                        testResult = err ?: "连接成功"
                        testing = false
                    }
                }) {
                    if (testing) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp) else Text("测试连接")
                }
            }
            if (saved) Text("已保存", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            testResult?.let {
                Text(it, style = MaterialTheme.typography.bodyMedium, color = if (testOk) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            }
        }
    }
    if (showModelPicker) {
        AlertDialog(
            onDismissRequest = { showModelPicker = false },
            title = { Text("选择模型（${modelList.size}）") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    modelList.forEach { m ->
                        Text(
                            m,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (m == model) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.fillMaxWidth()
                                .clickable { model = m; showModelPicker = false; saved = false }
                                .padding(vertical = 8.dp)
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showModelPicker = false }) { Text("取消") } }
        )
    }
}

@Composable
private fun SettingsField(
    label: String,
    value: String,
    isPassword: Boolean = false,
    onChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        visualTransformation = if (isPassword) PasswordVisualTransformation() else VisualTransformation.None,
        modifier = Modifier.fillMaxWidth()
    )
}