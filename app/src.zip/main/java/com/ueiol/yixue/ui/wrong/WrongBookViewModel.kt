package com.ueiol.yixue.ui.wrong

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.runtime.Composable
import com.ueiol.yixue.YixueApp
import com.ueiol.yixue.data.db.AnswerRecordEntity
import com.ueiol.yixue.data.db.QuestionDao
import com.ueiol.yixue.data.db.QuestionEntity
import com.ueiol.yixue.data.db.SubjectDao
import com.ueiol.yixue.data.db.SubjectEntity
import com.ueiol.yixue.data.db.WrongQuestionDao
import com.ueiol.yixue.data.db.WrongQuestionEntity
import com.ueiol.yixue.domain.agent.ReviewAgent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class WrongItem(
    val wrong: WrongQuestionEntity,
    val question: QuestionEntity?,
    val record: AnswerRecordEntity?
)

class WrongBookViewModel(
    private val subjectDao: SubjectDao,
    private val wrongQuestionDao: WrongQuestionDao,
    private val questionDao: QuestionDao,
    private val recordDao: com.ueiol.yixue.data.db.AnswerRecordDao,
    private val reviewAgent: ReviewAgent
) : ViewModel() {

    val subjects: StateFlow<List<SubjectEntity>> = subjectDao.observeAll()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val _selectedSubjectId = MutableStateFlow<Long?>(null)
    val selectedSubjectId: StateFlow<Long?> = _selectedSubjectId

    val wrongItems: StateFlow<List<WrongItem>> = _selectedSubjectId
        .flatMapLatest { sid ->
            if (sid == null) wrongQuestionDao.observeActive()
            else wrongQuestionDao.observeActiveBySubject(sid)
        }
        .map { list ->
            list.map { wq ->
                WrongItem(wq, questionDao.getById(wq.questionId), recordDao.getByQuestionId(wq.questionId))
            }
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun selectSubject(id: Long?) { _selectedSubjectId.value = id }

    fun markMastered(item: WrongItem) {
        viewModelScope.launch { wrongQuestionDao.setMastered(item.wrong.id, true) }
    }

    private val _explaining = MutableStateFlow(false)
    val explaining: StateFlow<Boolean> = _explaining

    private val _explainError = MutableStateFlow<String?>(null)
    val explainError: StateFlow<String?> = _explainError

    /** 勾选错题批量 AI 精讲，结果写入错题记录。 */
    fun explain(items: List<WrongItem>, onDone: (List<Long>) -> Unit) {
        if (_explaining.value || items.isEmpty()) return
        viewModelScope.launch {
            _explaining.value = true
            _explainError.value = null
            val done = mutableListOf<Long>()
            try {
                for (item in items) {
                    val q = item.question ?: continue
                    val (letters, accepted) = com.ueiol.yixue.domain.grading.GradingEngine
                        .decodeAnswer(q.answerJson, q.type != "FILL_BLANK")
                    val correct = if (letters.isNotEmpty()) letters.joinToString(" ") else (accepted.firstOrNull() ?: "")
                    val report = reviewAgent.explain(
                        q.stem, item.record?.valueJson ?: "未作答", correct, q.mistakeTag ?: ""
                    )
                    wrongQuestionDao.updateExplanationReport(item.wrong.id, report)
                    done.add(item.wrong.id)
                }
            } catch (t: Throwable) {
                _explainError.value = "精讲失败：${t.message?.take(120)}"
            } finally {
                _explaining.value = false
            }
            if (done.isNotEmpty()) onDone(done)
        }
    }

    companion object {
        @Composable
        fun create(): WrongBookViewModel = viewModel(factory = viewModelFactory {
            initializer {
                val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as YixueApp
                val c = app.container
                WrongBookViewModel(c.subjectDao, c.wrongQuestionDao, c.questionDao, c.answerRecordDao, c.reviewAgent)
            }
        })
    }
}