package com.ueiol.yixue.ui.notebook

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Undo
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Functions
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.ueiol.yixue.ui.common.MarkdownBlock
import com.ueiol.yixue.ui.formula.FormulaEditorDialog
import com.ueiol.yixue.ui.theme.FlymeExt
import kotlinx.coroutines.launch

/** 笔记编辑器：Markdown + 图片/函数图/公式/表格插入 + 预览 + 自动保存。 */
@Composable
fun NoteEditorPage(
    vm: NoteEditorViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val title by vm.title.collectAsState()
    val content by vm.content.collectAsState()
    val saving by vm.saving.collectAsState()
    val savedTick by vm.savedTick.collectAsState()
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current

    var preview by remember { mutableStateOf(false) }
    var showFormulaDialog by remember { mutableStateOf(false) }
    // 非空表示正在编辑预览里点中的那条公式
    var editingLatex by remember { mutableStateOf<String?>(null) }
    var showPlot by remember { mutableStateOf(false) }
    var plotExpr by remember { mutableStateOf("") }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                vm.importImage(uri)?.let { md -> vm.onContentChange(appendMd(content, md)) }
            }
        }
    }

    Column(modifier = modifier.fillMaxSize().imePadding()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { vm.flush(); onBack() }) {
                Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "返回", tint = MaterialTheme.colorScheme.onSurface)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(if (title.isBlank()) "新笔记" else title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface, maxLines = 1, fontWeight = FontWeight.SemiBold)
                Text(if (saving) "保存中…" else "已自动保存", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = { preview = !preview }) {
                Icon(if (preview) Icons.Outlined.Edit else Icons.Outlined.Visibility, contentDescription = "预览", tint = MaterialTheme.colorScheme.onSurface)
            }
        }
        if (!preview) {
            OutlinedTextField(
                value = title,
                onValueChange = { vm.onTitleChange(it) },
                placeholder = { Text("标题") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            )
            // 插入工具栏
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(selected = false, onClick = { imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, label = { Text("图片") })
                FilterChip(selected = false, onClick = { showPlot = true }, label = { Text("函数图") })
                FilterChip(
                    selected = showFormulaDialog,
                    onClick = { focusManager.clearFocus(); showFormulaDialog = true },
                    label = { Text("公式") }
                )

            }
        }
        if (preview) {
            Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp)) {
                Text(title, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onSurface)
                Spacer(Modifier.height(8.dp))
                MarkdownBlock(
                    text = content,
                    onLatexClick = { latex -> editingLatex = latex }
                )
            }
        } else {
            OutlinedTextField(
                value = TextFieldValue(content, selection = TextRange(content.length)),
                onValueChange = { vm.onContentChange(it.text) },
                placeholder = { Text("Markdown 内容…") },
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp)
            )
        }
    }

    if (showFormulaDialog) {
        FormulaEditorDialog(
            onDismiss = { showFormulaDialog = false },
            onConfirm = { latex ->
                vm.onContentChange(appendMd(content, "$$\n" + latex + "\n$$"))
            }
        )
    }

    // 预览里点公式 → 回填到编辑器，保存时替换对应的那段 LaTeX
    editingLatex?.let { old ->
        FormulaEditorDialog(
            title = "编辑公式",
            initialLatex = old,
            onDismiss = { editingLatex = null },
            onConfirm = { latex ->
                vm.onContentChange(replaceFormula(content, old, latex))
            }
        )
    }

    if (showPlot) {
        PlotDialog(
            expr = plotExpr,
            onExprChange = { plotExpr = it },
            onDismiss = { showPlot = false },
            onInsert = { md -> vm.onContentChange(appendMd(content, md)); showPlot = false }
        )
    }
}
/** 在 Markdown 末尾追加内容（保证独立成行）。 */
private fun appendMd(current: String, add: String): String {
    if (current.isBlank()) return add
    return current.trimEnd('\n') + "\n\n" + add
}

private fun insertAtCursor(current: String, add: String): String = appendMd(current, add)

/** 用新的 LaTeX 替换笔记里指定的那条公式（兼容块级与行内两种写法）。 */
private fun replaceFormula(content: String, oldLatex: String, newLatex: String): String {
    val block = "$$\n$oldLatex\n$$"
    if (content.contains(block)) return content.replaceFirst(block, "$$\n$newLatex\n$$")
    val inline = "$$" + oldLatex + "$$"
    if (content.contains(inline)) return content.replaceFirst(inline, "$$" + newLatex + "$$")
    return content.replaceFirst(oldLatex, newLatex)
}

@Composable
private fun PlotDialog(
    expr: String,
    onExprChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onInsert: (String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("插入函数图") },
        text = {
            Column {
                OutlinedTextField(
                    value = expr,
                    onValueChange = onExprChange,
                    placeholder = { Text("如 y=x^2, x=-5..5（可多行，每行一条）") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onDismiss(); onInsert("```plot\n$expr\n```") }, enabled = expr.isNotBlank()) { Text("插入") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } }
    )
}