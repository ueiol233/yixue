package com.ueiol.yixue.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ueiol.yixue.YixueApp
import com.ueiol.yixue.data.db.SubjectEntity
import com.ueiol.yixue.ui.common.FlymeLargeTitle
import com.ueiol.yixue.ui.theme.FlymeCardShape
import com.ueiol.yixue.ui.theme.FdPrimaryBlueLight
import com.ueiol.yixue.ui.theme.FdPrimaryCyanLight
import com.ueiol.yixue.ui.theme.FdPrimaryGreenLight
import com.ueiol.yixue.ui.theme.FdPrimaryOrangeLight
import com.ueiol.yixue.ui.theme.FdPrimaryPurpleLight
import com.ueiol.yixue.ui.theme.FdPrimaryRedLight
import com.ueiol.yixue.ui.theme.FdPrimaryYellowLight
import kotlinx.coroutines.launch

private val COLORS = listOf(FdPrimaryBlueLight, FdPrimaryGreenLight, FdPrimaryOrangeLight, FdPrimaryPurpleLight, FdPrimaryYellowLight, FdPrimaryCyanLight, FdPrimaryRedLight)

/** 科目管理：新增 / 删除 / 颜色轮换。 */
@Composable
fun SubjectsPage(onBack: () -> Unit, modifier: Modifier = Modifier) {
    val app = LocalApp()
    val subjects by app.container.subjectDao.observeAll()
        .collectAsState(initial = emptyList())
    var adding by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var deleting by remember { mutableStateOf<SubjectEntity?>(null) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()

    Column(modifier = modifier.fillMaxSize()) {
        FlymeLargeTitle(title = "科目管理", actions = {
            IconButton(onClick = { adding = true }) {
                Icon(Icons.Outlined.Add, contentDescription = "新增科目", tint = MaterialTheme.colorScheme.onSurface)
            }
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "返回", tint = MaterialTheme.colorScheme.onSurface)
            }
        })
        LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(subjects, key = { it.id }) { s ->
                Card(
                    shape = FlymeCardShape,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                    modifier = Modifier.fillMaxWidth().clickable { deleting = s }
                ) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(12.dp).background(COLORS[s.colorIndex % 7], CircleShape))
                        Spacer(Modifier.size(12.dp))
                        Text(s.name, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                        if (s.autoCreated) Text("AI 归档", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }

    if (adding) {
        AlertDialog(
            onDismissRequest = { adding = false },
            title = { Text("新增科目") },
            text = { OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("科目名") }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    val n = newName.trim()
                    if (n.isNotEmpty()) {
                        val c = app.container
                        scope.launch {
                            val count = c.subjectDao.count()
                            c.subjectDao.insert(
                                SubjectEntity(name = n, colorIndex = count % 7, order = count)
                            )
                        }
                        adding = false
                        newName = ""
                    }
                }) { Text("确定") }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text("取消") } }
        )
    }
    deleting?.let { s ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("删除科目「${s.name}」？") },
            text = { Text("已归档的错题仍保留在题目中，但不再按此科目展示。") },
            confirmButton = { TextButton(onClick = { deleting = null }) { Text("删除") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("取消") } }
        )
    }
}

@androidx.compose.runtime.Composable
private fun LocalApp(): YixueApp =
    androidx.compose.ui.platform.LocalContext.current.applicationContext as YixueApp