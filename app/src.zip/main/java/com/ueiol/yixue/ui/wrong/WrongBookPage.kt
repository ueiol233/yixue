package com.ueiol.yixue.ui.wrong

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.FactCheck
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.ueiol.yixue.ui.common.EmptyState
import com.ueiol.yixue.ui.common.FlymeLargeTitle
import com.ueiol.yixue.ui.common.MarkdownBlock
import com.ueiol.yixue.ui.common.inlineMd
import com.ueiol.yixue.ui.theme.FlymeCardShape
import com.ueiol.yixue.ui.theme.FlymeExt
import com.ueiol.yixue.ui.theme.FlymeRadius
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val SUBJECT_COLORS = listOf(
    com.ueiol.yixue.ui.theme.FdPrimaryBlueLight, com.ueiol.yixue.ui.theme.FdPrimaryGreenLight,
    com.ueiol.yixue.ui.theme.FdPrimaryOrangeLight, com.ueiol.yixue.ui.theme.FdPrimaryPurpleLight,
    com.ueiol.yixue.ui.theme.FdPrimaryYellowLight, com.ueiol.yixue.ui.theme.FdPrimaryCyanLight,
    com.ueiol.yixue.ui.theme.FdPrimaryRedLight
)

/** 错题本：按科目分组、勾选精讲、标记掌握。 */
@Composable
fun WrongBookPage(vm: WrongBookViewModel, modifier: Modifier = Modifier) {
    val subjects by vm.subjects.collectAsState()
    val items by vm.wrongItems.collectAsState()
    val selectedSubject by vm.selectedSubjectId.collectAsState()
    val explaining by vm.explaining.collectAsState()
    val explainError by vm.explainError.collectAsState()
    val selected = remember { mutableListOf<Long>().toMutableStateList() }
    var reportFor by remember { mutableStateOf<Long?>(null) }

    Column(modifier = modifier.fillMaxSize()) {
        FlymeLargeTitle(title = "错题本", actions = {
            if (selected.isNotEmpty()) {
                Button(onClick = {
                    val chosen = items.filter { it.wrong.id in selected }
                    vm.explain(chosen) { ids -> reportFor = ids.first() }
                }, enabled = !explaining) {
                    if (explaining) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                    else Text("精讲(${selected.size})")
                }
            }
        })
        // 科目筛选
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                FilterChip(selected = selectedSubject == null, onClick = { vm.selectSubject(null) }, label = { Text("全部") })
            }
            items(subjects, key = { it.id }) { s ->
                FilterChip(
                    selected = selectedSubject == s.id,
                    onClick = { vm.selectSubject(s.id) },
                    label = { Text(s.name) },
                    leadingIcon = {
                        Box(Modifier.size(8.dp).background(SUBJECT_COLORS[s.colorIndex % 7], CircleShape))
                    }
                )
            }
        }
        explainError?.let {
            Text(it, color = FlymeExt.subjectRed, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        }
        if (items.isEmpty()) {
            EmptyState(
                icon = Icons.AutoMirrored.Outlined.FactCheck,
                title = "还没有错题",
                hint = "完成一次测验后，错题会自动归档到这里",
                modifier = Modifier.padding(bottom = 96.dp)
            )
        } else {
            LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(items, key = { it.wrong.id }) { item ->
                    WrongCard(
                        item = item,
                        subjectColor = SUBJECT_COLORS[(subjects.firstOrNull { it.id == item.wrong.subjectId }?.colorIndex ?: 0) % 7],
                        subjectName = subjects.firstOrNull { it.id == item.wrong.subjectId }?.name ?: "",
                        selected = item.wrong.id in selected,
                        onSelect = { if (item.wrong.id in selected) selected.remove(item.wrong.id) else selected.add(item.wrong.id) },
                                onOpen = { reportFor = item.wrong.id },
                        onMastered = { vm.markMastered(item); selected.remove(item.wrong.id) }
                    )
                }
            }
        }
    }

    // 精讲报告 / 错题详情
    reportFor?.let { wid ->
        val item = items.firstOrNull { it.wrong.id == wid }
        if (item != null) {
            androidx.compose.material3.AlertDialog(
                onDismissRequest = { reportFor = null },
                title = { Text("错题详情") },
                text = {
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                        item.question?.let { MarkdownBlock(text = it.stem) }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            inlineMd("我的答案：${item.record?.valueJson ?: "未作答"}"),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        item.question?.let { q ->
                            val (letters, accepted) = com.ueiol.yixue.domain.grading.GradingEngine
                                .decodeAnswer(q.answerJson, q.type != "FILL_BLANK")
                            Text(
                                inlineMd("正确答案：${if (letters.isNotEmpty()) letters.joinToString(" ") else (accepted.firstOrNull() ?: "")}"),
                                style = MaterialTheme.typography.bodySmall,
                                color = FlymeExt.success
                            )
                        }
                        item.question?.aiReason0(item.record)?.let {
                            Text(inlineMd(it), style = MaterialTheme.typography.labelMedium, color = FlymeExt.warning)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("AI 精讲", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                        val report = item.wrong.explanationReport
                        if (report.isNullOrBlank()) {
                            Text("尚未生成。勾选此题并点击顶部「精讲」按钮。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else {
                            MarkdownBlock(text = report)
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { reportFor = null }) { Text("关闭") } }
            )
        }
    }
}

private fun com.ueiol.yixue.data.db.QuestionEntity.aiReason0(record: com.ueiol.yixue.data.db.AnswerRecordEntity?): String? =
    record?.aiReason?.let { "复核意见：$it" }
@Composable
private fun WrongCard(
    item: WrongItem,
    subjectColor: androidx.compose.ui.graphics.Color,
    subjectName: String,
    selected: Boolean,
    onSelect: () -> Unit,
    onOpen: () -> Unit,
    onMastered: () -> Unit
) {
    val timeFmt = remember { SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()) }
    val q = item.question
    Card(
        shape = FlymeCardShape,
        colors = CardDefaults.cardColors(
            containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
            else MaterialTheme.colorScheme.surfaceContainerLowest
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).background(subjectColor, CircleShape))
                Spacer(Modifier.size(6.dp))
                Text(subjectName, style = MaterialTheme.typography.labelMedium, color = subjectColor)
                item.question?.mistakeTag?.let { tag ->
                    Spacer(Modifier.size(8.dp))
                    Text(tag, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.background(MaterialTheme.colorScheme.surfaceContainerHigh, RoundedCornerShape(FlymeRadius.ExtraMini)).padding(horizontal = 6.dp, vertical = 2.dp))
                }
                if (item.record?.state == "AI_REVERSED") {
                    Spacer(Modifier.size(8.dp))
                    Text("AI 改判", style = MaterialTheme.typography.labelSmall, color = FlymeExt.success)
                }
                Spacer(Modifier.weight(1f))
                Text(timeFmt.format(Date(item.wrong.wrongAt)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                q?.stem ?: "题目已删除",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 3
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TextButton(onClick = onSelect) {
                    Text(if (selected) "取消选择" else "选择精讲")
                }
                TextButton(onClick = onMastered) { Text("已掌握") }
            }
        }
    }
}