package com.ueiol.yixue.ui.chat

import android.net.Uri
import android.util.Base64
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ueiol.yixue.YixueApp
import com.ueiol.yixue.data.ai.OpenAiClient
import com.ueiol.yixue.data.db.QuizSummary
import com.ueiol.yixue.data.db.SessionEntity
import com.ueiol.yixue.data.repo.ChatRepository
import com.ueiol.yixue.data.repo.QuizRepository
import com.ueiol.yixue.domain.agent.Prompts
import com.ueiol.yixue.domain.agent.QuizAgent
import com.ueiol.yixue.domain.model.ApiFuncCall
import com.ueiol.yixue.domain.model.ApiMessage
import com.ueiol.yixue.domain.model.ApiToolCall
import com.ueiol.yixue.domain.model.ChatMessage
import com.ueiol.yixue.domain.model.ToolDef
import com.ueiol.yixue.domain.model.ToolFunction
import com.ueiol.yixue.domain.model.assistantToolCallMessage
import com.ueiol.yixue.domain.model.toApiMessage
import com.ueiol.yixue.domain.model.toolResultMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/** 工具调用状态：name = 工具名，label = 展示给用户的一句话。 */
data class ToolActivity(val name: String, val label: String)

class ChatViewModel(
    private val repo: ChatRepository,
    private val quizRepo: QuizRepository,
    private val quizAgent: QuizAgent,
    private val aiClient: OpenAiClient,
    private val app: YixueApp,
    private val isConfigured: () -> Boolean
) : ViewModel() {

    val sessions: StateFlow<List<SessionEntity>> = repo.observeSessions()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val _currentSessionId = MutableStateFlow<Long?>(null)
    val currentSessionId: StateFlow<Long?> = _currentSessionId

    val messages = _currentSessionId
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repo.observeMessages(id) }

    /** 非空表示正在流式接收 */
    private val _streamingText = MutableStateFlow<String?>(null)
    val streamingText: StateFlow<String?> = _streamingText

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    // ---------- Agent 工具：generate_quiz ----------

    /** 工具调用进行中的状态（聊天页展示"正在做什么"）。 */
    private val _toolActivity = MutableStateFlow<ToolActivity?>(null)
    val toolActivity: StateFlow<ToolActivity?> = _toolActivity

    /** 会话中练习卡片所需的试卷汇总（按 id 索引）。 */
    val quizSummaries: StateFlow<Map<Long, QuizSummary>> = quizRepo.observeSummaries()
        .map { list -> list.associateBy { it.id } }
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyMap())

    companion object {
        const val TOOL_QUIZ = "generate_quiz"

        val quizTool = ToolDef(
            function = ToolFunction(
                name = TOOL_QUIZ,
                description = "生成一套练习题并自动打开答题卡。当用户想要出题、练习、做题、测验、巩固某个知识点时必须调用此工具，不要在回复文本中直接写题目。",
                parameters = Json.parseToJsonElement(
                    """
                    {"type":"object","properties":{
                      "subject":{"type":"string","description":"科目，如 数学/物理/英语"},
                      "types":{"type":"array","items":{"type":"string","enum":["single","multiple","fill"]},"description":"题型：single单选 multiple多选 fill填空"},
                      "count":{"type":"integer","description":"题目数量"},
                      "difficulty":{"type":"string","description":"难度：简单/中等/困难"},
                      "topic":{"type":"string","description":"考察的知识点或范围描述"}
                    },"required":["subject","count"]}
                    """.trimIndent()
                )
            )
        )

        /** 从工具参数构造出题请求描述。 */
        fun quizRequestFromArgs(args: String): String {
            val obj = runCatching { Json.parseToJsonElement(args).jsonObject }.getOrNull()
            if (obj == null) return args
            val subject = (obj["subject"] as? JsonPrimitive)?.content ?: "综合"
            val count = (obj["count"] as? JsonPrimitive)?.content?.toIntOrNull() ?: 5
            val types = (obj["types"] as? JsonArray)
                ?.mapNotNull { (it as? JsonPrimitive)?.content }
                ?.joinToString("、")
                ?.let { mapTypes(it) } ?: "单选、填空"
            val difficulty = (obj["difficulty"] as? JsonPrimitive)?.content ?: "中等"
            val topic = (obj["topic"] as? JsonPrimitive)?.content ?: ""
            return "科目：$subject；题型：$types；数量：$count；难度：$difficulty" +
                (if (topic.isNotBlank()) "；知识点：$topic" else "") + "。请生成一套练习题。"
        }

        private fun mapTypes(joined: String): String {
            var s = joined
            s = s.replace("single", "单选").replace("multiple", "多选").replace("fill", "填空")
            return s
        }
    }
    init {
        viewModelScope.launch {
            // 空会话不保存：先清掉历史遗留的空会话，再打开最近一条有内容的会话
            repo.deleteEmptySessions()
            _currentSessionId.value = repo.observeSessions().first().firstOrNull()?.id
        }
    }

    /** 新对话先不落库，第一次发消息时才创建会话。 */
    fun newChat() {
        if (_streamingText.value != null) return
        _currentSessionId.value = null
    }

    fun selectSession(id: Long) {
        if (_streamingText.value != null) return
        _currentSessionId.value = id
    }

    /** 交卷报告：挂到输入框上方作为"附件"，由用户确认后再发送。 */
    private val _pendingReport = MutableStateFlow<String?>(null)
    val pendingReport: StateFlow<String?> = _pendingReport

    fun attachReport(sessionId: Long?, report: String) {
        if (report.isBlank()) return
        // AI 正在回复时先挂上报告，等回复结束再发；此时不切换会话来打断流
        if (_streamingText.value == null && (sessionId ?: 0L) > 0) {
            _currentSessionId.value = sessionId
        }
        _pendingReport.value = report.trim()
    }

    fun clearPendingReport() { _pendingReport.value = null }

    fun renameSession(id: Long, title: String) {
        viewModelScope.launch { repo.renameSession(id, title.trim().ifEmpty { "未命名" }) }
    }

    fun togglePin(session: SessionEntity) {
        viewModelScope.launch { repo.setPinned(session.id, !session.pinned) }
    }

    fun deleteSession(session: SessionEntity) {
        viewModelScope.launch {
            repo.deleteSession(session)
            if (_currentSessionId.value == session.id) _currentSessionId.value = null
        }
    }

    fun dismissError() {
        _error.value = null
    }

    // ---------- 图片附件（视觉提问） ----------

    private val _pendingImage = MutableStateFlow<String?>(null)
    val pendingImage: StateFlow<String?> = _pendingImage

    fun attachImage(uri: Uri) {
        viewModelScope.launch {
            try {
                val dataUrl = withContext(Dispatchers.IO) {
                    val bytes = app.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                        ?: return@withContext null
                    val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    "data:image/jpeg;base64,$b64"
                }
                if (dataUrl != null) _pendingImage.value = dataUrl
            } catch (t: Throwable) {
                _error.value = "图片读取失败：${t.message ?: "未知错误"}"
            }
        }
    }

    fun clearPendingImage() { _pendingImage.value = null }

    // ---------- Agent 对话循环 ----------

    fun send(text: String) = sendWithImages(text, emptyList())

    fun sendWithImages(text: String, externalImages: List<String>) {
        // 输入框文字 + 挂着的答题报告一起发送
        val typed = text.trim()
        val report = _pendingReport.value
        val body = buildString {
            if (typed.isNotEmpty()) append(typed)
            if (report != null) {
                if (typed.isNotEmpty()) append("\n\n")
                append(report)
            }
        }.trim()
        if (body.isEmpty() || _streamingText.value != null) return
        if (!isConfigured()) {
            _error.value = "请先到「我的 → AI 服务设置」配置接口地址与 API Key"
            return
        }
        viewModelScope.launch {
            try {
                val sessionId = _currentSessionId.value ?: repo.createSession()
                    .also { _currentSessionId.value = it }
                val images = if (externalImages.isEmpty()) listOfNotNull(_pendingImage.value) else externalImages
                _pendingImage.value = null
                _pendingReport.value = null
                repo.addUserMessage(sessionId, body, images)
                _streamingText.value = ""

                val apiMsgs = ArrayList<ApiMessage>()
                apiMsgs += ChatMessage("system", Prompts.CHAT_SYSTEM).toApiMessage()
                repo.historyMessages(sessionId).forEach { m ->
                    apiMsgs += ChatMessage(m.role, m.content, repo.attachmentsOf(m)).toApiMessage()
                }

                // Agent 循环：模型可多次调用工具，最多 3 轮
                var finalText: String? = null
                var quizIdForReply: Long? = null
                var round = 0
                try {
                    while (finalText == null && round < 3) {
                        round++
                        val result = aiClient.streamApi(apiMsgs, tools = listOf(quizTool)) { delta ->
                            _streamingText.value = (_streamingText.value ?: "") + delta
                        }
                        if (!result.hasToolCalls) {
                            finalText = result.content
                            break
                        }
                        apiMsgs += assistantToolCallMessage(
                            result.toolCalls.map { ApiToolCall(it.id, "function", ApiFuncCall(it.name, it.arguments)) }
                        )
                        for (tc in result.toolCalls) {
                            val toolResult = if (tc.name == TOOL_QUIZ) {
                                _toolActivity.value = ToolActivity(TOOL_QUIZ, "正在生成练习…")
                                val (message, quizId) = executeQuizTool(tc.arguments)
                                if (quizId != null) quizIdForReply = quizId
                                _toolActivity.value = null
                                message
                            } else {
                                "未知工具：${tc.name}"
                            }
                            apiMsgs += toolResultMessage(tc.id, toolResult)
                        }
                        _streamingText.value = (_streamingText.value ?: "") + "\n\n"
                    }
                } finally {
                    _toolActivity.value = null
                }

                val reply = finalText ?: "（工具调用轮次已达上限）"
                // 把试卷挂在这条回复上，聊天页据此渲染练习卡片
                repo.addAssistantMessage(sessionId, reply.trim(), quizIdForReply)
                _streamingText.value = null
            } catch (t: Throwable) {
                _error.value = t.message ?: "请求失败"
                _streamingText.value = null
            }
        }
    }

    /** 执行出题工具：生成试卷 → 入库，返回（给模型的结果文本, 试卷 id）。 */
    private suspend fun executeQuizTool(argsJson: String): Pair<String, Long?> {
        val request = quizRequestFromArgs(argsJson)
        return try {
            val spec = quizAgent.generate(request)
            val quizId = quizRepo.createFromSpec(_currentSessionId.value, spec)
            "试卷《${spec.title}》已生成（共 ${spec.questions.size} 题），已在对话中生成练习卡片。" to quizId
        } catch (t: Throwable) {
            "出题失败：${t.message ?: "未知错误"}。请告知用户稍后重试。" to null
        }
    }
}