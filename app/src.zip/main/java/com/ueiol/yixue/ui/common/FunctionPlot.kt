package com.ueiol.yixue.ui.common

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.ueiol.yixue.domain.plot.ExpressionParser
import com.ueiol.yixue.ui.theme.FlymeExt
import kotlin.math.abs

data class PlotSpec(
    val expressions: List<String>,
    val xMin: Double = -10.0,
    val xMax: Double = 10.0,
    val yMin: Double = -8.0,
    val yMax: Double = 8.0
)

object PlotParser {
    /** 解析绘图指令行："y=x^2" 或 "y=x^2, x=-5..5" 或 "..., x=-5..5, y=-2..8"。 */
    fun parseLines(lines: List<String>): PlotSpec? {
        val exprs = mutableListOf<String>()
        var xMin = -10.0; var xMax = 10.0
        var yMin: Double? = null; var yMax: Double? = null
        for (raw in lines) {
            val line = raw.trim().trimStart('-', '>', ' ')
            if (line.isEmpty()) continue
            val parts = line.split(',')
            exprs.add(parts[0].trim())
            for (k in 1 until parts.size) {
                val seg = parts[k].trim().replace(" ", "")
                val m = Regex("([xy])=(-?[0-9.]+)\\.\\.(-?[0-9.]+)").find(seg) ?: continue
                val lo = m.groupValues[2].toDoubleOrNull() ?: continue
                val hi = m.groupValues[3].toDoubleOrNull() ?: continue
                when (m.groupValues[1]) {
                    "x" -> { xMin = lo; xMax = hi }
                    "y" -> { yMin = lo; yMax = hi }
                }
            }
        }
        if (exprs.isEmpty()) return null
        return PlotSpec(exprs, xMin, xMax, yMin ?: -8.0, yMax ?: 8.0)
    }
}

/**
 * 函数图像组件（Compose Canvas）：网格 + 坐标轴 + 多条曲线，支持捏合缩放与拖动。
 */
@Composable
fun FunctionPlot(spec: PlotSpec, modifier: Modifier = Modifier) {
    val compiled = remember(spec) {
        spec.expressions.mapNotNull { e ->
            runCatching { ExpressionParser.compile(e) }.getOrNull()
        }
    }
    var view by remember(spec) {
        mutableStateOf(doubleArrayOf(spec.xMin, spec.xMax, spec.yMin, spec.yMax))
    }
    val curveColors = listOf(
        Color(0xFF206CFF), FlymeExt.subjectGreen, FlymeExt.subjectOrange,
        FlymeExt.subjectPurple, FlymeExt.subjectCyan, FlymeExt.subjectRed
    )
    val gridColor = Color.Gray.copy(alpha = 0.25f)
    val axisColor = Color.Gray.copy(alpha = 0.7f)

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .height(220.dp)
            .pointerInput(spec) {
                detectTransformGestures { _, pan, zoom, _ ->
                    val cx = (view[0] + view[1]) / 2
                    val cy = (view[2] + view[3]) / 2
                    val halfW = (view[1] - view[0]) / 2 / zoom
                    val halfH = (view[3] - view[2]) / 2 / zoom
                    view[0] = cx - halfW; view[1] = cx + halfW
                    view[2] = cy - halfH; view[3] = cy + halfH
                    val w = view[1] - view[0]
                    val h = view[3] - view[2]
                    val dx = pan.x / size.width * w
                    val dy = pan.y / size.height * h
                    view[0] -= dx; view[1] -= dx
                    view[2] += dy; view[3] += dy
                }
            }
    ) {
        val xMin = view[0]; val xMax = view[1]; val yMin = view[2]; val yMax = view[3]
        val w = size.width; val h = size.height
        fun sx(x: Double) = ((x - xMin) / (xMax - xMin) * w).toFloat()
        fun sy(y: Double) = (h - ((y - yMin) / (yMax - yMin) * h)).toFloat()

        // 网格
        val xStep = niceStep(xMax - xMin)
        val yStep = niceStep(yMax - yMin)
        var gx = Math.floor(xMin / xStep) * xStep
        while (gx <= xMax) { drawLine(gridColor, Offset(sx(gx), 0f), Offset(sx(gx), h), 1f); gx += xStep }
        var gy = Math.floor(yMin / yStep) * yStep
        while (gy <= yMax) { drawLine(gridColor, Offset(0f, sy(gy)), Offset(w, sy(gy)), 1f); gy += yStep }
        // 坐标轴
        if (yMin <= 0 && yMax >= 0) drawLine(axisColor, Offset(sx(0.0), 0f), Offset(sx(0.0), h), 2f)
        if (xMin <= 0 && xMax >= 0) drawLine(axisColor, Offset(0f, sy(0.0)), Offset(w, sy(0.0)), 2f)

        // 曲线
        val n = 300
        compiled.forEachIndexed { idx, fn ->
            val color = curveColors[idx % curveColors.size]
            val path = Path()
            var drawing = false
            var prevY: Double? = null
            for (k in 0..n) {
                val x = xMin + (xMax - xMin) * k / n
                val y = runCatching { fn(x) }.getOrNull() ?: Double.NaN
                if (y.isNaN() || y.isInfinite() || (prevY != null && abs(y - prevY) > (yMax - yMin) * 4)) {
                    drawing = false; prevY = if (y.isNaN()) null else y
                    continue
                }
                val px = sx(x); val py = sy(y)
                if (!drawing) { path.moveTo(px, py); drawing = true } else path.lineTo(px, py)
                prevY = y
            }
            drawPath(path, color, style = Stroke(width = 5f))
        }
    }
}

private fun niceStep(range: Double): Double {
    val raw = range / 10
    val mag = Math.pow(10.0, Math.floor(Math.log10(raw)))
    val norm = raw / mag
    val mult = when {
        norm < 1.5 -> 1.0; norm < 3.0 -> 2.0; norm < 7.0 -> 5.0; else -> 10.0
    }
    return mult * mag
}