package com.ueiol.yixue.ui.formula

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.setValue

/** 公式结构节点（可视化编辑用）。 */
sealed interface FNode

data class FText(val text: String) : FNode

/** 分数：分子槽 / 分母槽 */
data class FDiv(val numSlot: Int, val denSlot: Int) : FNode

/** 幂：底数槽 / 指数槽 */
data class FPow(val baseSlot: Int, val expSlot: Int) : FNode

/** 下标：底数槽 / 下标槽 */
data class FSub(val baseSlot: Int, val subSlot: Int) : FNode

/** 根号：根号内槽 */
data class FSqrt(val bodySlot: Int) : FNode

/**
 * 可视化公式状态机：
 * 以「槽位(slot)」组织，结构可嵌套；输入永远进入当前聚焦槽位。
 */
class FormulaState {

    private var nextId = 1
    val root: Int = 0

    val slots = mutableStateMapOf<Int, MutableList<FNode>>()

    /** 槽位 → 所属父槽位，用于退格回到上一层。 */
    private val slotParent = mutableMapOf<Int, Int>()

    var focused by mutableIntStateOf(0)
        private set

    init {
        slots[0] = mutableStateListOf()
    }

    fun nodes(slot: Int): MutableList<FNode> = slots.getOrPut(slot) { mutableStateListOf() }

    fun focus(slot: Int) { focused = slot }

    fun insertText(s: String) {
        if (s.isEmpty()) return
        val list = nodes(focused)
        val last = list.lastOrNull()
        if (last is FText) list[list.size - 1] = FText(last.text + s)
        else list.add(FText(s))
    }

    fun backspace() {
        val list = nodes(focused)
        if (list.isEmpty()) {
            val parent = slotParent[focused]
            if (parent != null) focused = parent
            return
        }
        val last = list.last()
        when (last) {
            is FText -> {
                if (last.text.length <= 1) list.removeAt(list.size - 1)
                else list[list.size - 1] = FText(last.text.dropLast(1))
            }
            else -> list.removeAt(list.size - 1)
        }
    }

    /** 插入分数线结构，聚焦分子。 */
    fun insertDiv() {
        val num = nextId++
        val den = nextId++
        slots[num] = mutableStateListOf()
        slots[den] = mutableStateListOf()
        slotParent[num] = focused
        slotParent[den] = focused
        nodes(focused).add(FDiv(num, den))
        focused = num
    }

    /** 插入幂：把前一个文本节点抬为底数，聚焦指数。 */
    fun insertPow() {
        val base = nextId++
        val exp = nextId++
        slots[base] = mutableStateListOf()
        slots[exp] = mutableStateListOf()
        slotParent[base] = focused
        slotParent[exp] = focused
        val list = nodes(focused)
        val last = list.lastOrNull()
        if (last is FText) {
            list.removeAt(list.size - 1)
            slots[base]!!.add(last)
        }
        list.add(FPow(base, exp))
        focused = exp
    }

    /** 插入下标：把前一个文本节点抬为底数，聚焦下标。 */
    fun insertSub() {
        val base = nextId++
        val sub = nextId++
        slots[base] = mutableStateListOf()
        slots[sub] = mutableStateListOf()
        slotParent[base] = focused
        slotParent[sub] = focused
        val list = nodes(focused)
        val last = list.lastOrNull()
        if (last is FText) {
            list.removeAt(list.size - 1)
            slots[base]!!.add(last)
        }
        list.add(FSub(base, sub))
        focused = sub
    }

    /** 插入根号，聚焦根号内。 */
    fun insertSqrt() {
        val body = nextId++
        slots[body] = mutableStateListOf()
        slotParent[body] = focused
        nodes(focused).add(FSqrt(body))
        focused = body
    }

    fun clear() {
        nextId = 1
        slots.clear()
        slotParent.clear()
        slots[0] = mutableStateListOf()
        focused = 0
    }

    fun isEmpty(): Boolean = slots.values.all { it.isEmpty() }

    /** 导出 LaTeX（用于存储与判分）。 */
    fun toLatex(): String = slotLatex(root)

    private fun slotLatex(slot: Int): String = buildString {
        nodes(slot).forEach { n ->
            when (n) {
                is FText -> append(latexSafe(n.text))
                is FDiv -> append("\\frac{${slotLatex(n.numSlot)}}{${slotLatex(n.denSlot)}}")
                is FPow -> append("{${slotLatex(n.baseSlot)}}^{${slotLatex(n.expSlot)}}")
                is FSub -> append("{${slotLatex(n.baseSlot)}}_{${slotLatex(n.subSlot)}}")
                is FSqrt -> append("\\sqrt{${slotLatex(n.bodySlot)}}")
            }
        }
    }

    /** 键盘输入的 Unicode 运算符转成 LaTeX，保证导出可被解析。 */
    private fun latexSafe(s: String): String = s
        .replace("×", "\\times ")
        .replace("÷", "\\div ")
        .replace("·", "\\cdot ")
        .replace("−", "-")
        .replace("π", "\\pi ")
        .replace("≤", "\\leq ")
        .replace("≥", "\\geq ")
        .replace("≠", "\\neq ")
        .replace("≈", "\\approx ")
        .replace("±", "\\pm ")
        .replace("∞", "\\infty ")
        .replace("√", "\\surd ")
}