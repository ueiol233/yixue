package com.ueiol.yixue

import android.app.Application
import com.ueiol.yixue.data.AppContainer

class YixueApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
