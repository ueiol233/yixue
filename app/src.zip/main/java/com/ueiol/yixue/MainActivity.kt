package com.ueiol.yixue

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.ueiol.yixue.ui.navigation.MainScreen
import com.ueiol.yixue.ui.theme.YixueTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            YixueTheme {
                MainScreen()
            }
        }
    }
}
